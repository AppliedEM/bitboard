g++ test.cpp point.cpp -o test

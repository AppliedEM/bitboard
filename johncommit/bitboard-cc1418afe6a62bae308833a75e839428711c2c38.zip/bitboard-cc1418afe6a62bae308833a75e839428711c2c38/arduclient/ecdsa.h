class ecdsa
{
  public:
    //const static point G;
    static point sign(bn z,bn r,bn k_inv, bn secret);
  private:

};

const extern bn N;
